#include "BinarySearchTree.h"

int main() {
    BinarySearchTree bst(6);

    bst.insert(bst.getroot(), 9);
    bst.insert(bst.getroot(), 1);
    bst.insert(bst.getroot(), 6);
    bst.insert(bst.getroot(), 8);
    bst.insert(bst.getroot(), 11);

    std::cout << "Initial Tree Structure:\n" << bst.printTree() << std::endl;

    std::cout << "Search 10: " << (bst.search(bst.getroot(), 10) ? "Found" : "Not Found") << std::endl;
    std::cout << "Search 11: " << (bst.search(bst.getroot(), 11) ? "Found" : "Not Found") << std::endl;

    return 0;
}
