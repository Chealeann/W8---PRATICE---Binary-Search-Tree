#ifndef BINARYSEARCHTREE_H
#define BINARYSEARCHTREE_H

#include <iostream>
#include <string>
#include <queue>
#include "Node.h"

class BinarySearchTree {
private:
    Node* root;

public:
    BinarySearchTree() : root(nullptr) {}
    BinarySearchTree(int value) {
        root = new Node(value);
    }

    int calculateHeight() {
        return calculateHeight(root);
    }

    Node* getroot() {
        return root;
    }

    std::string printTree() {
        std::string result = "";
        printTree(root, 0, result);
        return result;
    }

    // Exercise 1
    bool search(Node* root, int key) {
        if (root == nullptr) return false; // Key not found
        if (root->data == key) return true; // Key found
        if (key < root->data) return search(root->left, key); // Search in left subtree
        return search(root->right, key); // Search in right subtree
    }

    void insert(Node* root, int newValue) {
        if (newValue < root->data) {
            if (root->left == nullptr)
                root->left = new Node(newValue); // Insert here
            else
                insert(root->left, newValue); // Continue to left subtree
        } else {
            if (root->right == nullptr)
                root->right = new Node(newValue); // Insert here
            else
                insert(root->right, newValue); // Continue to right subtree
        }
    }

    void deleteNode(Node*& root, int value) {
        if (root == nullptr) return;

        if (value < root->data)
            deleteNode(root->left, value); // Search in left subtree
        else if (value > root->data)
            deleteNode(root->right, value); // Search in right subtree
    }

    // Exercise 2
    std::string levelOrderTraverse() {
        std::string result = "";
        if (root == nullptr) return result;

        std::queue<Node*> q;
        q.push(root);

        while (!q.empty()) {
            Node* current = q.front();
            q.pop();
            result += std::to_string(current->data) + " ";

            if (current->left != nullptr) q.push(current->left);
            if (current->right != nullptr) q.push(current->right);
        }

        return result;
    }

private:
    Node* findMin(Node* node) {
        while (node->left != nullptr) {
            node = node->left;
        }
        return node;
    }

    void printTree(Node* node, int depth, std::string& result) {
        if (node == nullptr) return;
        for (int i = 0; i < depth; ++i) {
            result += "- ";
        }
        result += std::to_string(node->data) + "\n";
        printTree(node->left, depth + 1, result);
        printTree(node->right, depth + 1, result);
    }

    int calculateHeight(Node* node) {
        if (node == nullptr) return 0;
        int leftHeight = calculateHeight(node->left);
        int rightHeight = calculateHeight(node->right);
        return std::max(leftHeight, rightHeight) + 1;
    }
};

#endif // BINARYSEARCHTREE_H
